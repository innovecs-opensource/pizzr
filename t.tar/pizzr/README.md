pizzr
=====

arrange ordering food to the office in handy way

- - -

pip install -r requirements.txt
